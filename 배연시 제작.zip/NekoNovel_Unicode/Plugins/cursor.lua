
--[[

사용가능한 네코노벨 객체
nekoImage
nekoLabel
nekoSound
nekoButton
nekoSystemButton
nekoParticle

block 내 공통 함수
 
 - block:GetName() : 이름을 가져온다.
 - block:SetZOrder(value) : 블럭의 출력 순서를 조정한다.
 - block:GetOrder(value) : 블럭의 출력 순서를 가져온다.
 - block:SetVisible(visible) : 블럭의 표시 여부를 결정한다.
 - block:IsVisible() : 블럭의 표시 여부를 가져온다.
 - block:SetPosition(x, y) : 블럭의 위치를 조정한다.
 - block:GetX() : 블럭의 X좌표를 가져온다.
 - block:GetY() : 블럭의 Y좌표를 가져온다.
 - block:GetWidth() : 블럭의 가로 크기를 가져온다.
 - block:GetHeight() : 블럭의 세로 크기를 가져온다.
 -
 - block:GetAlpha() : 현재 알파값을 가져온다.
 - block:SetAlpha(alpha) : 블럭의 알파값을 조정한다. (사운드 일 경우 볼륨)
 - block:GetRotation() : 현재 회전각도를 가져온다.
 - block:SetRotation(angle) : 회전 각도를 수정한다.
 - block:SetScale(x, y) : 블럭의 scale 크기를 조정한다. (기본값 1, 1)
 - block:GetScaleX() : scale의 가로값을 가져온다.
 - block:GetScaleY() : scale의 세로값을 가져온다.
 - block:Play() : 블럭을 재생한다.
 - block:Stop(pause) : 블럭을 정지한다. (pause가 true일 경우, 일시정지)
 - block:SetIgnoreCamera(ignore) : 블럭이 카메라의 영향을 받을지 결정한다.
 - block:IsIgnoreCamera() : 블럭이 카메라의 영향을 받는지 체크한다.
 - block:Destroy() : 블럭을 제거한다.
 -
 - block:ToImage() : 이미지 일 경우, nekoImage로 변환한다.
 - block:ToLabel() : 라벨 일 경우, nekoLabel로 변환한다.
 - block:ToSound() : 효과음 일 경우, nekoSound로 변환한다.
 - block:ToButton() : 버튼 일 경우, nekoButton로 변환한다.
 - block:ToSystemButton() : 시스템 버튼 일 경우, nekoSystemButton로 변환한다.
 - block:ToParticle() : 파티클 일 경우, nekoParticle로 변환한다.
 - 
 
 
nekoImage 내 함수
 - image:SetHue(color) : 이미지에 색조를 입힌다. 
 - image:LoadFile(filename) : 새로운 이미지 파일로 교체한다.
 
nekoLabel 내 함수
 - label:SetText(text) : 라벨의 텍스트 속성을 정한다.
 - label:SetColor(color) : 라벨의 색조를 바꾼다.
 - label:SetFont(name, size, bold) : 라벨의 폰트를 바꾼다.
 
nekoParticle 내 함수
 - particle:Reset() : 파티클을 처음부터 다시 실행한다.
 
nekoButton 내 함수
 - button:SetRollover(rolloverImage, rolloverSound)
 
nekoSystemButton 내 함수
 - button:SetRollover(rolloverImage, rolloverSound)
 
env 내 함수
 - env:Eval(text) : 새로운 쓰레드에서 네코노벨 명령을 실행한다.
 - env:EnableUpdate(enable) : 매 프레임 마다 OnUpdate 함수가 실행되도록 한다. (퍼포먼스에 영향을 줄 수 있으므로, 잘 사용할 것.)
 - env:GetGameWidth() : 게임의 가로 해상도 크기
 - env:GetGameHeight() : 게임의 세로 해상도 크기
 - env:GetMouseX() : 현재 마우스의 X 좌표 위치
 - env:GetMouseY() : 현재 마우스의 Y 좌표 위치
 - env:GetMouseButton(v) : 어떤 마우스 버튼이 눌렸는지 체크. (v에는 0(왼쪽), 1(가운데), 2(오른쪽) 중 하나가 들어간다.)
 - env:GetBlock(name) : 해당 이름의 블럭을 찾는다.
 - env:Destroy() : 플러그인 객체 자체를 사라지게 한다.
 -
 - env:CreateImage(name, fileName) : 이미지를 생성한다.
 - env:CreateLabel(name, text, color) : 라벨을 생섷안다.
 - env:CreateSound(name, fileName, repeat) : 효과음을 생성한다. repeat은 반복되는 횟수이다.
 - env:CreateParticle(name, fileName) : 파티클을 생성한다.
 - env:CreateButton(name, normalImage, pressedImage, pressedSound)
            : 누르면 사라지는 일반 버튼을 생성한다. 누를 경우에 OnEvent로 이벤트가 전달된다.
 - env:CreateSystemButton(name, normalImage, pressedImage, pressedSound)
            : 아무것도 하지 않는 사라지지 않는 버튼을 생성한다. 누를 경우에 OnEvent로 이벤트가 전달된다.
 - 

data 내 함수
 - data:Set(key, value) : key와 value 쌍의 데이터를 등록한다.
 - data:Get(key) : key로 등록된 value 데이터를 가져온다.

OnEvent로 전달되는 이벤트 타입
 - E_MOUSE_DOWN : 마우스가 클릭 되었다. arg에 마우스 버튼 번호가 전달된다.
 - E_MOUSE_UP : 마우스가 클릭 되었다가, 일반 상태로 돌아갔다. arg에 마우스 버튼 번호가 전달된다.
 - E_BUTTON_DOWN : 블럭 중 어느 버튼이 클릭 되었을 경우, 전달된다. arg에 버튼 이름이 전달된다. (버튼과, 시스템 버튼 모두 해당된다.)

루아 테스트 custom_sprite.lua

루아메세지 테스트 HELLO
]]--

-- 플러그인이 새로 생성되거나, 로드되었을 경우 호출 됩니다.
-- data 객체가 만약 존재한다면, 게임 로드로 부터 생성되었음을 의미합니다.
function OnStart(env, data)
    print 'OnStart'
    
    -- 마우스를 따라다니는 커서 만들기
    cursor = env:CreateImage('@커서', '커서.png')
    cursor:SetScale(3, 3)
    
    -- 로드된 게임이라면, 기존 데이터 가져오기
    if data ~= nil then
        v = data:Get("hello", "35") 
        print ("hello = " .. v)
    end
    
    -- 매 프레임마다 OnUpdate 호출하게 하기
    env:EnableUpdate(true)
    
    -- 현재 시간 변수 가져와서 표시하기
    print ('현재시간 : ' .. env:GetVar('%현재시간'))
end

-- 플러그인이 게임 로드 파일에 저장되어야 할때 호출됩니다.
-- data 객체를 통해 필요한 데이터를 저장하세요.
function OnDump(env, data)
    print 'OnDump'
    data:Set("hello", "35")
end

-- 매 프레임(1/60초) 마다 실행되는 함수 입니다.
-- dt는 이전 프레임과 현재 프레임의 시간 차이를 저장하고 있습니다.
-- 60fps 기준으로 했을때에는 약 0.16 입니다.

function OnUpdate(env, dt)
    -- 커서의 위치를 마우스 좌표로 옮기기. (따라 다니게 하기)
    cursor:SetPosition(env:GetMouseX(), env:GetMouseY())
    
end

-- 플러그인이 명령어에 의해 사라지거나, 지우기로 삭제될 떄 호출됩니다.
function OnDestroy(env)
    print 'OnDestroy'
end

-- 네코노벨 스크립트를 통해 전송된 메세지를 받습니다.
-- 이 함수에서 리턴 시, 네코노벨 스크립트에서 %리턴값 변수로 접근할 수 있습니다.

function OnMessage(env, text)
    print ("OnMessage text=" .. text)
    
    -- 1+1 이라는 메세지를 받으면, 긔요미! 라고 리턴한다.
    -- 이 리턴값은 네코노벨에서 %리턴값 변수로 받아올 수 있다.
    if text == "1+1" then
        return "긔요미!"
    end
    
    return nil
end

-- 네코노벨에서 발생하는 이벤트를 받을떄 사용합니다.
function OnEvent(env, type, arg)
   
    -- 마우스 버튼이 눌렸다.
    if type == E_MOUSE_DOWN then
        
        x = env:GetMouseX()
        y = env:GetMouseY()
        print ("마우스 버튼을 눌렀다! 버튼="..arg..", x = "..x..", y = "..y)
        
        -- 커서의 색깔을 임의로 조정한다.
        cursor:SetHue(math.random(0, 100000000))
    
    -- 마우스 버튼이 떼졌다.
    elseif type == E_MOUSE_UP then
        x = env:GetMouseX()
        y = env:GetMouseY()
        print ("마우스 버튼을 뗐다! 버튼="..arg..", x = "..x..", y = "..y)
        
    -- 버튼이나 시스템 버튼이 눌렸다.
    elseif type == E_BUTTON_DOWN then
        print ("버튼이 눌렸다 이름 = " .. arg)
    end
end

